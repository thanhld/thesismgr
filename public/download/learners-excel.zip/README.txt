*** HƯỚNG DẪN NHẬP DANH SÁCH DỮ LIỆU TỪ EXCEL ***
Chuyên viên Khoa được cấp quyền nhập danh sách các đối tượng sau bằng tệp EXCEL
- Giảng viên
- Học viên

0. YÊU CẦU ĐỐI VỚI TỆP 
- Tệp được đọc phải là tệp EXCEL.
- Tệp EXCEL hợp lệ có đuôi mở rộng là '.xlsx' hoặc '.xls'.
- Tệp EXCEL yêu cầu CHỈ CHỨA bảng dữ liệu, không yêu cầu chứa các hàng văn bản khác.
- Các trường hợp khác, được coi là tệp không hợp lệ, và hệ thống không đọc dữ liệu thành công.

1. CÁC TRƯỜNG YÊU CẦU BẮT BUỘC TRONG BẢNG DỮ LIỆU EXCEL
BẢNG DỮ LIỆU bao gồm các trường cụ thể:
- STT: số thứ tự các hàng dữ liệu trong bảng EXCEL.
- Tên tài khoản: tên tài khoản người dùng được cấp để sử dụng trong hệ thống.
- Mật khẩu: mật khẩu chưa mã hóa của người dùng, mặc định do Khoa cấp.
- Mã học viên: mã học viên được cấp trong trường Đại học Công nghệ.
- Tên học viên: họ tên đầy đủ của học viên.
- VNU email: địa chỉ thử điện tử VNU do trường đại học cấp cho học viên.
- Khóa đào tạo: đơn vị học viên đang công tác trong trường Đại học Công nghệ.

2. YÊU CẦU CHUNG VỚI CÁC TRƯỜNG DỮ LIỆU
- Tên các trường phải đúng, đủ, không thêm bớt kí tự.
giống như trong tệp excel mẫu đã đặt.

3. YÊU CẦU VỚI MỖI TRƯỜNG TRONG BẢNG DỮ LIỆU
- STT:
+ Bắt buộc đối với mỗi hàng dữ liệu.
+ STT sẽ được sử dụng để làm đơn vị thông báo nếu hàng dữ liệu không được đọc thành công.

- Tên tài khoản:
+ Bắt buộc đói với mỗi hàng dữ liệu.
+ Tên tài khoản không được giống nhau giữa các hàng dữ liệu.

- Mật khẩu:
+ Bắt buộc đối với mỗi hàng dữ liệu.

- Mã học viên:
+ Bắt buộc đối với mỗi hàng dữ liệu.
+ Mã học viên không được giống nhau giữa các hàng dữu liệu.

- Tên học viên:
+ Bắt buộc đối với mỗi hàng dữ liệu.

- VNU email:
+ Địa chỉ mail hợp lệ có đuôi '@vnu.edu.vn'
+ Địa chỉ mail không được giống nhau giữa các hàng dữu liệu.

- Khóa đào tạo:
+ Một khóa đào tạo phải đã tồn tại trong hệ thống của chương trình.
+ Bắt buộc đối với mỗi hàng dữ liệu.
+ Một khóa đào tạo phải có tên trùng với tên một trong các khóa đào tạo được quản lý trong danh sách của Khoa.

4. CÁC TRƯỜNG HỢP KHÔNG HỢP LỆ
- Tệp không phải EXCEL (không có đuôi .xlsx hoặc .xls).
- Tệp chứa các hàng dữ liệu thừa, không chỉ chứa bảng dữ liệu.
- Địa chỉ mail không hợp lệ: không có định dạng VNU email.
- Khóa đào tạo không tồn tại. Khóa đào tạo không thuộc Khoa hiện tại.
- Tên tài khoản, mật khẩu không hợp lệ.
- Thiếu trường trong bảng dữ liệu.
- Trường được yêu cầu nhưng hàng dữ liệu tại trường đó không có giá trị hợp lệ.

