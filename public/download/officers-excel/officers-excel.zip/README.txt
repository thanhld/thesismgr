*** HƯỚNG DẪN NHẬP DANH SÁCH DỮ LIỆU TỪ EXCEL ***
Chuyên viên Khoa được cấp quyền nhập danh sách các đối tượng sau bằng tệp EXCEL
- Cán bộ
- Học viên

0. YÊU CẦU ĐỐI VỚI TỆP 
- Tệp được đọc phải là tệp EXCEL.
- Tệp EXCEL hợp lệ có đuôi mở rộng là '.xlsx' hoặc '.xls'.
- Tệp EXCEL yêu cầu CHỈ CHỨA bảng dữ liệu, không yêu cầu chứa các hàng văn bản khác.
- Các trường hợp khác, được coi là tệp không hợp lệ, và hệ thống không đọc dữ liệu thành công.

1. CÁC TRƯỜNG YÊU CẦU BẮT BUỘC TRONG BẢNG DỮ LIỆU EXCEL
BẢNG DỮ LIỆU bao gồm các trường cụ thể:
- STT: số thứ tự các hàng dữ liệu trong bảng EXCEL.
- Tên tài khoản: tên tài khoản người dùng được cấp để sử dụng trong hệ thống.
- Mật khẩu: mật khẩu chưa mã hóa của người dùng, mặc định do Khoa cấp.
- Mã cán bộ: mã cán bộ được cấp trong trường Đại học Công nghệ.
- Tên cán bộ: họ tên đầy đủ của cán bộ.
- VNU email: địa chỉ thử điện tử VNU do trường đại học cấp cho cán bộ.
- Cán bộ: vị trí / vai trò của cán bộ trong hệ thống.
- Học hàm, học vị: bậc học vị của cán bộ
- Đơn vị công tác: đơn vị cán bộ đang công tác trong trường Đại học Công nghệ.

2. YÊU CẦU CHUNG VỚI CÁC TRƯỜNG DỮ LIỆU
- Tên các trường phải đúng, đủ, không thêm bớt kí tự.
giống như trong tệp excel mẫu đã đặt.

3. YÊU CẦU VỚI MỖI TRƯỜNG TRONG BẢNG DỮ LIỆU
- STT:
+ Bắt buộc đối với mỗi hàng dữ liệu.
+ STT sẽ được sử dụng để làm đơn vị thông báo nếu hàng dữ liệu không được đọc thành công.

- Tên tài khoản:
+ Bắt buộc đói với mỗi hàng dữ liệu.
+ Tên tài khoản không được giống nhau giữa các hàng dữ liệu.

- Mật khẩu:
+ Bắt buộc đối với mỗi hàng dữ liệu.

- Mã cán bộ:
+ Bắt buộc đối với mỗi hàng dữ liệu.
+ Mã cán bộ không được giống nhau giữa các hàng dữu liệu.

- Tên cán bộ:
+ Bắt buộc đối với mỗi hàng dữ liệu.

- VNU email:
+ Địa chỉ email hợp lệ có đuôi '@vnu.edu.vn'
+ Địa chỉ email không được giống nhau giữa các hàng dữu liệu.

- Cán bộ:
+ Bắt buộc đối với mỗi hàng dữ liệu.
+ Vị trí / vai trò của cán bộ phải có tên trùng với ba loại sau: Chuyên viên; Giảng viên; Cán bộ ngoài. Các giá trị khác coi như không hợp lệ.

- Học hàm, học vị:
+ Không bắt buộc
+ Tên học hàm, học vị phải trùng với danh sách tên học hàm, học vị được liệt kê trong danh sách các học hàm học vị sau (yêu cầu viết chính xác kí tự): GS. TS.; PGS. TS.; TS.; ThS.; CN. 

- Đơn vị công tác:
+ Một đơn vị phải đã tồn tại trong hệ thống của chương trình.
+ Bắt buộc đối với mỗi hàng dữ liệu.
+ Một đơn vị phải có tên trùng với tên đã được đặt trong trang quản lý danh sách đơn vị.

4. CÁC TRƯỜNG HỢP KHÔNG HỢP LỆ
- Tệp không phải EXCEL (không có đuôi .xlsx hoặc .xls).
- Tệp chứa các hàng dữ liệu thừa, không chỉ chứa bảng dữ liệu.
- Địa chỉ mail không hợp lệ: không có định dạng VNU mail.
- Học hàm học vị / Đơn vị công tác không tồn tại. Đơn vị coogn tác không thuộc Khoa hiện tại.
- Tên tài khoản, mật khẩu, vị trí cán bộ không hợp lệ.
- Thiếu trường trong bảng dữ liệu.
- Trường được yêu cầu nhưng hàng dữ liệu tại trường đó không có giá trị hợp lệ.

